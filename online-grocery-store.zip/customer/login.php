<?php
include '../includes/dbconnect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // BUG FIX: Select 'is_verified' alongside customer data
    $stmt = $conn->prepare("SELECT customer_id, customer_password, is_verified FROM customers WHERE customer_email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify the hashed password
        if (password_verify($password, $user['customer_password'])) {
            
            // BUG FIX: Check if the user has verified their email address
            if ((int)$user['is_verified'] === 1) {
                $_SESSION['customer_id'] = $user['customer_id'];
                header("Location: index.php"); 
                exit();
            } else {
                // If account is registered but not verified yet, redirect them back to OTP page
                $error = "Your account is not verified yet. Please check your email for the OTP code or <a href='verify_otp.php?email=" . urlencode($email) . "'>verify here</a>.";
            }
            
        } else {
            $error = "Invalid email address or password.";
        }
    } else {
        $error = "Invalid email address or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Online Grocery System</title>
    <link rel="stylesheet" href="includes/styles.css"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <style>
        body {
            background-image: url('images/login_background.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        /* Optional overlay fallback or wrapper adjustment if readability becomes tricky */
        .auth-container {
            background-color: rgba(255, 255, 255, 0.95); /* Slight opacity to contrast with the image background */
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .footer-container, .footer-container .copy {
            color: #ffffff !important;
        }
    </style>
</head>
<body>

<?php include 'includes/header.php'; ?>


<div class="auth-container">
    <h2>LOGIN TO YOUR ACCOUNT</h2>

    <!-- Error Message Display -->
    <?php if (isset($error)): ?>
        <div class="error-msg" style="color: red; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center;">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <!-- Registration Success Message -->
    <?php if (isset($_GET['registration']) && $_GET['registration'] == 'success'): ?>
        <div class="success-msg" style="color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center;">
            Registration successful! You can now log in.
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <label for="email">Email Address:</label>
        <input type="email" name="email" required placeholder="Enter your email">

        <label for="password">Password:</label>
        <div class="password-wrapper">
            <input type="password" name="password" id="loginPassword" required placeholder="Enter your password">
            <span class="material-icons toggle-eye" onclick="toggleSinglePass('loginPassword', this)">visibility_off</span>
        </div>

        <button type="submit" class="btn">Login</button>
    </form>
    
    <p style="margin-top: 15px;">
        Don't have an account? <a href="register.php">Register here</a>
    </p>
    <p>
        Forgot your password? <a href="forgot_password.php">Reset it here</a>
    </p>
</div>

<script>
function toggleSinglePass(fieldId, iconElement) {
    const passwordField = document.getElementById(fieldId);
    
    if (passwordField.type === "password") {
        passwordField.type = "text";
        iconElement.textContent = "visibility"; // Changes icon to open eye
    } else {
        passwordField.type = "password";
        iconElement.textContent = "visibility_off"; // Changes icon to slashed eye
    }
}
</script>
<?php include 'includes/footer.php'; ?>
</body>
</html>